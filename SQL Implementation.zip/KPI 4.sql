CREATE DEFINER=`root`@`localhost` PROCEDURE `KPI_4`()
BEGIN
select  department ,avg(totalworkingyears) as Wise_Average_working_years, sum(totalworkingyears) as Total_Working_Years 
from combine group by department ;
END