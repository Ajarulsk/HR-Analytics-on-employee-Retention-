CREATE DEFINER=`root`@`localhost` PROCEDURE `KPI_1`()
BEGIN
select distinct department,  count(Attrition_rate)*100/25105 As Attrition_Percentage
 from Combine where attrition = "Yes" group by department order by Attrition_Percentage desc;
END