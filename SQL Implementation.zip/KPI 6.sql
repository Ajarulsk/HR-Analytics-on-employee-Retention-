CREATE DEFINER=`root`@`localhost` PROCEDURE `KPI_6`()
BEGIN
select concat(11*floor(YearsSinceLastPromotion/11), '-', 11*floor(YearsSinceLastPromotion/11) + 10) as `Mothly_Income_Range`,
       count(Attrition_rate)*100/25105 as `Attrition_Rate ` from combine
       where attrition = "Yes" group by 1 order by YearsSinceLastPromotion;
END