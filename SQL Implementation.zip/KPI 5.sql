CREATE DEFINER=`root`@`localhost` PROCEDURE `KPI_5`()
BEGIN
 select JobRole,worklifebalance2,round((avg(sum(WorkLifeBalance)) over (PARTITION BY JobRole,worklifebalance2))) 
 as wrkbal_per_jobrl from combineeditcsv 
group by  worklifebalance2,JobRole;
END