CREATE DEFINER=`root`@`localhost` PROCEDURE `KPI_3`()
BEGIN
select concat(11001*floor(Monthlyincome/11001), '-', 11001*floor(Monthlyincome/11001) + 11000) as `Mothly_Income_Range`,
       count(Attrition_rate)*100/50000 as `Attrition_Rate ` from combine
       where attrition = "Yes" group by 1 order by Monthlyincome;
END