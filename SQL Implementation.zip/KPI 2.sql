CREATE DEFINER=`root`@`localhost` PROCEDURE `KPI_2`()
BEGIN
select avg(hourlyrate) as Average_hourly_rate_male_research_scientist 
from combine where gender ='male' and jobrole='Research Scientist' ;
END